import React from 'react';
import ReactDOM from 'react-dom';

import App1 from './App';
import Form from "./Form"
import 'bootstrap/dist/css/bootstrap.css';
// function based component VS class based component
// props
const Person = (props) => {
  const { name, lname } = props;
  return (
    <div>
      {/* <p> {props.name} </p> */}
      <p> {name} </p>
      <h3> {lname} </h3>
    </div>
  )
}

function App() {
  return (
    <div>
      <Form />
    </div>
    // JSX
  )
}

ReactDOM.render(<App />, document.getElementById("root"));












// const age = 25;
// const currentAge = calculateAge("Sep 15, 1990");
// const age1 = calc();

// function calc(a, b) {
//   console.log(a + b)
// }

// function calculateAge(dob) {
//   const birthday = new Date(dob);
//   const diff = Date.now() - birthday.getTime();
//   const ageDate = new Date(diff);
//   const age = ageDate.getUTCFullYear() - 1970;
//   return age;
// }



// calculateAge("12-15-1993");

// console.log(age);
