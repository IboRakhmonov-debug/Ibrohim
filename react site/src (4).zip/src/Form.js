import React, { Component } from 'react'

class Form extends Component {

  state = {
    address: "123 main st"
  };

  render() {
    return (
      <div>
        <h1> {this.state.address} </h1>
      </div>
    )
  }
}

export default Form;